# DS WORLD APK project

हा Android WebView wrapper आहे. तो DS WORLD ची प्रकाशित website उघडतो आणि सध्याचा Firebase login/data flow वापरतो.

## Update कसे मिळतील?

या APK मध्ये website URL जोडलेला आहे. website वर नवा `index.html` publish झाल्यानंतर वापरकर्ता APK पुन्हा उघडेल तेव्हा ताजे पान लोड होईल. प्रत्येक UI/code बदलासाठी APK पुन्हा install करण्याची गरज नाही. फोनवर internet लागेल. Website publish नसेल तर APK मध्येही नवा बदल दिसणार नाही.

## APK तयार करणे

1. हा project GitHub repository मध्ये upload करा.
2. GitHub मधील **Actions → Build DS WORLD APK → Run workflow** निवडा. `main` branch वर push केल्यावरही build सुरू होतो.
3. Build पूर्ण झाल्यावर **DS-WORLD-APK** artifact डाउनलोड करा. त्यातील `app-debug.apk` Android फोनवर install करा.
4. फोनमध्ये “Install unknown apps” परवानगी द्या.

Android Studio मध्ये project उघडून `app` module चा `assembleDebug` build केला तरी APK तयार होतो.

## मर्यादा

- Website/ Firebase ला internet connection आवश्यक आहे.
- WebView APK मध्ये वेगळे Firebase project नाही; website चाच configured Firebase login वापरतो.
- या project मधून तयार होणारा APK सध्या debug build असेल. Play Store किंवा सार्वजनिक वितरणासाठी release key ने signed build लागतो. हा WebView APK published website उघडतो; वेबसाइटचे बदल APK मध्ये दिसण्यासाठी आधी website प्रकाशित असणे आवश्यक आहे.
- Android app signing key सुरक्षित ठेवा; key हरवल्यास त्याच package ID साठी in-place updates देता येत नाहीत.

## URL बदल

Website चा domain बदलल्यास `MainActivity.java` मधील `APP_URL` आणि `APP_HOST` दोन्ही बदला.
